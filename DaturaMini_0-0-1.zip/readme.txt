==Datura Mini v0.0.1, 4/19/2021 Prototype Build==

By A.Kei.KI, in GameMaker Studio 2

Thank you for playing! I hope you come back for the next release <3


==Controls==

Enter - Confirm
WASD - Menu Navigation/Movement
Space - Jump
I - Character 1 attack
O - Character 2 attack
P - Defend
Shift - Hyper mode


==Patch Notes==

=v0.0.1=
- Initial release
- 2 available characters
- 1 available stage
==Datura Mini v0.0.2, x/xx/2021 Prototype Build==

By @A.Kei.KI, in GameMaker Studio 2

Thank you for playing! I hope you come back for the next release <3


==Default Controls==

Enter       [A/Start]   Confirm
Arrow Keys  [DPad]      Menu navigation/Movement
Space       [A]         Jump
Z           [X]         Attack (character 1)
X           [Y]         Attack (character 2)
C                       Defend (current character)
Shift       [B]         Hyper mode
D                       Attack (current character)
A           [LB]        Defend (character 1)
S           [RB]        Defend (character 2)
F                       Switch characters


==Patch Notes==

=v0.0.1=
- Initial release
- 2 available characters
- 1 available stage

=v0.0.2=
- Attacks and defensive actions (including jumping) can now cancel into each-other
- Added rudimentary xinput support (only reads slot 0)
- Added placeholder audio
- Added additional controls to allow alternate methods of controlling the party
- Increased maximum jump height
- Ari Up-Atk no longer fails to spawn missiles if her back is against a wall
- Fixed inconsistent collision between Ari Atk and slopes
- Player projectiles now despawn upon exiting screen boundaries